# Student Hub — Diploma Engineering (Android)

A native Android app (Kotlin + Jetpack Compose) for Diploma Engineering and Diploma in
Robotics Engineering students: syllabus, notes, previous question papers, free books,
and mock tests with instant evaluation and unlimited retakes — no login required.

## What's included in this first version

- **Branches**: Diploma in Robotics Engineering (fully built out), plus starter branches
  for Mechanical, Computer Science, Electrical & Electronics, and Civil so the structure
  is proven across departments.
- **Syllabus**: unit-by-unit topic lists per subject.
- **Notes**: short revision notes per subject, opened in a clean reading screen.
- **Previous papers & Free books**: a reference list per subject. Items marked as a
  "link" open inside the app in a built-in web viewer (a "website modal") so students
  never have to leave the app; items marked "info" are placeholders reminding you to
  add real content.
- **Mock tests**: multiple-choice tests per subject with instant scoring, a
  right/wrong review with explanations, and unlimited retakes. Every attempt is saved
  on the student's own device (no account needed) so they can see their score history
  and track improvement over time.

Everything is designed to run **with no backend and no login** — all content ships
inside the app and all test history is stored privately on the student's phone.

## How the app is organized

```
StudentHub/
  app/src/main/assets/content.json      <- ALL course content lives here
  app/src/main/java/.../data/           <- data models + JSON loader + local storage
  app/src/main/java/.../screens/        <- each screen (Home, Branch, Subject, Test, ...)
  app/src/main/java/.../MainActivity.kt <- navigation between screens
```

## Adding or editing content (no coding needed)

Open `app/src/main/assets/content.json` in any text editor. It's a plain JSON file with
one entry per branch → semester → subject. Each subject can have:

- `syllabus`: a list of units, each with a title and a list of topics.
- `notes`: a list of `{ "title": ..., "content": ... }` — content is plain text.
- `papers` / `books`: a list of `{ "title", "subtitle", "kind", "value" }`.
  - `"kind": "link"` + `"value": "https://..."` opens that URL in the in-app viewer.
  - `"kind": "info"` + `"value": ""` shows a plain text placeholder (use this until you
    have a real PDF or link to add).
- `test`: `{ "id", "title", "durationMinutes", "questions": [...] }` where each question
  has `text`, `options` (list of 2–6 strings), `correctIndex` (0-based), and an optional
  `explanation` shown after the student answers.
- Set `"test": null` for a subject that doesn't have a mock test yet.

**Important:** every subject `id` and every test `id` in the whole file must be unique
(this is how the app tells subjects and test-attempt history apart), so when you copy an
existing entry to make a new one, always change its `id` values too.

To add a brand-new branch (e.g. another diploma stream), copy one of the existing
`{ "id": ..., "name": ..., "semesters": [...] }` blocks inside the `"branches"` array and
edit it — no code changes are needed for new content.

## Getting an installable APK file

This project's source code was written by hand in a cloud sandbox that has no Android
SDK and no internet access to Google's Maven repository, so the APK could not be
compiled here. There are two ways to get a real `.apk` file — pick whichever is easier
for you.

### Option A — no software install, build it in the cloud with GitHub Actions

A ready-made build recipe is already included at `.github/workflows/build-apk.yml`.
GitHub's own servers have full internet access and a pre-installed Android SDK, so they
can compile the APK for you for free — you only need a (free) GitHub account and a web
browser.

1. Go to github.com and sign in (or create a free account).
2. Click **New repository**, give it any name (e.g. `student-hub`), and create it.
3. On the new repo's page, click **Add file → Upload files**, then drag the *unzipped*
   `StudentHub` folder's contents (or the whole folder, in a browser that supports
   folder drag-and-drop, e.g. Chrome/Edge) into the upload box, and commit.
4. Click the **Actions** tab at the top of the repo. A workflow run should already be
   in progress (it starts automatically on upload); if not, click "Build APK" → **Run
   workflow**.
5. Wait 3–5 minutes for the green checkmark.
6. Click into the finished run, scroll down to **Artifacts**, and download
   `StudentHub-debug-apk` — that's a zip containing `app-debug.apk`.
7. Send that `.apk` file to your phone (email, Google Drive, WhatsApp, USB — whatever's
   easiest) and open it there. Android will warn about "installing from an unknown
   source" the first time since it's not from the Play Store — that's expected; allow
   it, then tap Install.

### Option B — build it yourself in Android Studio

1. Install [Android Studio](https://developer.android.com/studio) if you don't have it.
2. Open Android Studio → **Open** → select the `StudentHub` folder.
3. Let it sync (it will download Gradle and all dependencies automatically the first
   time — this needs internet access). If it asks about the Gradle wrapper, let Android
   Studio generate it for you.
4. Click the green **Run** button with a phone/emulator selected, or use
   **Build → Build Bundle(s) / APK(s) → Build APK(s)** to get an installable `.apk` file
   to share with students directly (Build → Generate Signed Bundle/APK for a Play
   Store–ready release build).

## Suggested next steps

- Fill in real previous-year papers and free book links per subject in `content.json`
  (or attach real PDF files to a cloud folder and link to them).
- Add the remaining subjects/semesters for each branch the same way.
- If you later want student accounts (to sync scores across devices, or let teachers see
  class-wide results), that would need a backend (e.g. Firebase) added on top of this —
  the current version deliberately keeps everything local and login-free to keep it
  simple to ship first.
