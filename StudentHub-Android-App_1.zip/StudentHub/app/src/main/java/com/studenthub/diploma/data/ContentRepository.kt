package com.studenthub.diploma.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reads the bundled content.json (assets/content.json) into the in-memory
 * model classes. To add new branches / subjects / questions, just edit that
 * JSON file -- this loader is generic and needs no changes.
 */
class ContentRepository(private val context: Context) {

    fun loadBranches(): List<Branch> {
        val json = context.assets.open("content.json").bufferedReader().use { it.readText() }
        val root = JSONObject(json)
        val branchesArray = root.getJSONArray("branches")
        return branchesArray.map { it as JSONObject }.map { parseBranch(it) }
    }

    private fun parseBranch(o: JSONObject): Branch = Branch(
        id = o.getString("id"),
        name = o.getString("name"),
        description = o.optString("description", ""),
        semesters = o.getJSONArray("semesters").map { it as JSONObject }.map { parseSemester(it) }
    )

    private fun parseSemester(o: JSONObject): Semester = Semester(
        number = o.getInt("number"),
        subjects = o.getJSONArray("subjects").map { it as JSONObject }.map { parseSubject(it) }
    )

    private fun parseSubject(o: JSONObject): Subject = Subject(
        id = o.getString("id"),
        name = o.getString("name"),
        code = o.optString("code", ""),
        syllabus = o.optJSONArray("syllabus")?.map { it as JSONObject }?.map { parseUnit(it) } ?: emptyList(),
        notes = o.optJSONArray("notes")?.map { it as JSONObject }?.map { parseNote(it) } ?: emptyList(),
        papers = o.optJSONArray("papers")?.map { it as JSONObject }?.map { parseReference(it) } ?: emptyList(),
        books = o.optJSONArray("books")?.map { it as JSONObject }?.map { parseReference(it) } ?: emptyList(),
        test = o.optJSONObject("test")?.let { parseTest(it) }
    )

    private fun parseUnit(o: JSONObject): SyllabusUnit = SyllabusUnit(
        unitNo = o.getInt("unitNo"),
        title = o.getString("title"),
        topics = o.getJSONArray("topics").map { it as String }
    )

    private fun parseNote(o: JSONObject): NoteItem = NoteItem(
        title = o.getString("title"),
        content = o.getString("content")
    )

    private fun parseReference(o: JSONObject): ReferenceItem = ReferenceItem(
        title = o.getString("title"),
        subtitle = o.optString("subtitle", ""),
        kind = o.optString("kind", "info"),
        value = o.optString("value", "")
    )

    private fun parseTest(o: JSONObject): MockTest = MockTest(
        id = o.getString("id"),
        title = o.getString("title"),
        durationMinutes = o.optInt("durationMinutes", 15),
        questions = o.getJSONArray("questions").map { it as JSONObject }.map { parseQuestion(it) }
    )

    private fun parseQuestion(o: JSONObject): Question = Question(
        id = o.getString("id"),
        text = o.getString("text"),
        options = o.getJSONArray("options").map { it as String },
        correctIndex = o.getInt("correctIndex"),
        explanation = o.optString("explanation", "")
    )
}

/** Small helper to make JSONArray iterable/mappable like a Kotlin list. */
private fun <T> JSONArray.map(transform: (Any) -> T): List<T> {
    val result = ArrayList<T>(length())
    for (i in 0 until length()) {
        result.add(transform(get(i)))
    }
    return result
}
