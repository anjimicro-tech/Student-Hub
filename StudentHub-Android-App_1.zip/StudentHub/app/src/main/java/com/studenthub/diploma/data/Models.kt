package com.studenthub.diploma.data

/**
 * Core content models. All content is loaded from assets/content.json so that
 * new branches, subjects, notes, papers, books and test questions can be added
 * by editing that one file -- no code changes needed.
 */

data class SyllabusUnit(
    val unitNo: Int,
    val title: String,
    val topics: List<String>
)

data class NoteItem(
    val title: String,
    val content: String
)

/**
 * A reference item (previous paper or free book).
 * kind is one of: "link" (opens in the in-app web viewer) or "info" (a plain
 * text pointer, e.g. "Ask your HOD for the department archive").
 */
data class ReferenceItem(
    val title: String,
    val subtitle: String,
    val kind: String,
    val value: String
)

data class Question(
    val id: String,
    val text: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

data class MockTest(
    val id: String,
    val title: String,
    val durationMinutes: Int,
    val questions: List<Question>
)

data class Subject(
    val id: String,
    val name: String,
    val code: String,
    val syllabus: List<SyllabusUnit>,
    val notes: List<NoteItem>,
    val papers: List<ReferenceItem>,
    val books: List<ReferenceItem>,
    val test: MockTest?
)

data class Semester(
    val number: Int,
    val subjects: List<Subject>
)

data class Branch(
    val id: String,
    val name: String,
    val description: String,
    val semesters: List<Semester>
)

data class TestAttempt(
    val testId: String,
    val subjectName: String,
    val score: Int,
    val total: Int,
    val timestampMillis: Long
)
