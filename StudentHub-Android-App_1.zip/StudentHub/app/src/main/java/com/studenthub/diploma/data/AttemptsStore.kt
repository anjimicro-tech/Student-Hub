package com.studenthub.diploma.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Stores mock-test attempt history on the device (no account/login needed).
 * Backed by a single JSON file in the app's private files directory, so
 * students can retake ("repeated tests access") any mock test and see their
 * past scores for self-evaluation.
 */
class AttemptsStore(private val context: Context) {

    private val file: File
        get() = File(context.filesDir, "attempts.json")

    fun getAttemptsForTest(testId: String): List<TestAttempt> =
        readAll().filter { it.testId == testId }.sortedByDescending { it.timestampMillis }

    fun getAllAttempts(): List<TestAttempt> =
        readAll().sortedByDescending { it.timestampMillis }

    fun addAttempt(attempt: TestAttempt) {
        val all = readAll().toMutableList()
        all.add(attempt)
        writeAll(all)
    }

    private fun readAll(): List<TestAttempt> {
        if (!file.exists()) return emptyList()
        return try {
            val text = file.readText()
            val array = JSONArray(text)
            val list = ArrayList<TestAttempt>()
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                list.add(
                    TestAttempt(
                        testId = o.getString("testId"),
                        subjectName = o.optString("subjectName", ""),
                        score = o.getInt("score"),
                        total = o.getInt("total"),
                        timestampMillis = o.getLong("timestampMillis")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeAll(attempts: List<TestAttempt>) {
        val array = JSONArray()
        attempts.forEach { attempt ->
            val o = JSONObject()
            o.put("testId", attempt.testId)
            o.put("subjectName", attempt.subjectName)
            o.put("score", attempt.score)
            o.put("total", attempt.total)
            o.put("timestampMillis", attempt.timestampMillis)
            array.put(o)
        }
        file.writeText(array.toString())
    }
}
