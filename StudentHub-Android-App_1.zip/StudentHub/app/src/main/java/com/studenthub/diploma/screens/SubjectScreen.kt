package com.studenthub.diploma.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.studenthub.diploma.data.ReferenceItem
import com.studenthub.diploma.data.Subject

private val TAB_TITLES = listOf("Syllabus", "Notes", "Papers", "Books", "Mock Test")

@Composable
fun SubjectScreen(
    subject: Subject,
    onBack: () -> Unit,
    onOpenNote: (Int) -> Unit,
    onOpenReferenceLink: (String, String) -> Unit,
    onStartTest: () -> Unit,
    onViewHistory: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(subject.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                TAB_TITLES.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }
            when (selectedTab) {
                0 -> SyllabusTab(subject)
                1 -> NotesTab(subject, onOpenNote)
                2 -> ReferenceTab(subject.papers, "No previous papers added yet for this subject.", onOpenReferenceLink)
                3 -> ReferenceTab(subject.books, "No free books linked yet for this subject.", onOpenReferenceLink)
                4 -> TestTab(subject, onStartTest, onViewHistory)
            }
        }
    }
}

@Composable
private fun SyllabusTab(subject: Subject) {
    if (subject.syllabus.isEmpty()) {
        EmptyState("Syllabus for this subject hasn't been added yet.")
        return
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(subject.syllabus) { unit ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Unit ${unit.unitNo}: ${unit.title}", style = MaterialTheme.typography.titleMedium)
                    unit.topics.forEach { topic ->
                        Text("• $topic", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun NotesTab(subject: Subject, onOpenNote: (Int) -> Unit) {
    if (subject.notes.isEmpty()) {
        EmptyState("No notes have been added yet for this subject.")
        return
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(subject.notes.size) { index ->
            val note = subject.notes[index]
            Card(
                onClick = { onOpenNote(index) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(Icons.Filled.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(note.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 12.dp).fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun ReferenceTab(items: List<ReferenceItem>, emptyMessage: String, onOpenLink: (String, String) -> Unit) {
    if (items.isEmpty()) {
        EmptyState(emptyMessage)
        return
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(items) { ref ->
            Card(
                onClick = { if (ref.kind == "link") onOpenLink(ref.title, ref.value) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (ref.kind == "link") Icons.Filled.Language else Icons.Filled.Description,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column(modifier = Modifier.padding(start = 12.dp)) {
                        Text(ref.title, style = MaterialTheme.typography.titleMedium)
                        if (ref.subtitle.isNotBlank()) {
                            Text(ref.subtitle, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TestTab(subject: Subject, onStartTest: () -> Unit, onViewHistory: (String) -> Unit) {
    val test = subject.test
    if (test == null) {
        EmptyState("No mock test has been added yet for this subject.")
        return
    }
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Icon(Icons.Filled.Quiz, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(test.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))
        Text(
            "${test.questions.size} questions • ${test.durationMinutes} minutes • unlimited retakes",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )
        Button(onClick = onStartTest, modifier = Modifier.fillMaxWidth()) {
            Text("Start test")
        }
        Button(
            onClick = { onViewHistory(test.id) },
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
        ) {
            Text("View my past attempts")
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(message, style = MaterialTheme.typography.bodyLarge)
    }
}
