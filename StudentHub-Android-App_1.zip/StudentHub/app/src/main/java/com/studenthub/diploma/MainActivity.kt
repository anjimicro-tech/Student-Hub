package com.studenthub.diploma

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.studenthub.diploma.data.AppViewModel
import com.studenthub.diploma.screens.BranchScreen
import com.studenthub.diploma.screens.HistoryScreen
import com.studenthub.diploma.screens.HomeScreen
import com.studenthub.diploma.screens.NoteDetailScreen
import com.studenthub.diploma.screens.ResultScreen
import com.studenthub.diploma.screens.SubjectScreen
import com.studenthub.diploma.screens.TestScreen
import com.studenthub.diploma.screens.WebViewScreen
import com.studenthub.diploma.ui.theme.StudentHubTheme
import java.net.URLDecoder
import java.net.URLEncoder

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudentHubTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    StudentHubApp(viewModel)
                }
            }
        }
    }
}

object Routes {
    const val HOME = "home"
    const val BRANCH = "branch/{branchId}"
    const val SUBJECT = "subject/{branchId}/{subjectId}"
    const val NOTE = "note/{branchId}/{subjectId}/{noteIndex}"
    const val WEBVIEW = "webview/{title}/{url}"
    const val TEST = "test/{branchId}/{subjectId}"
    const val RESULT = "result"
    const val HISTORY = "history/{testId}"

    fun branch(branchId: String) = "branch/$branchId"
    fun subject(branchId: String, subjectId: String) = "subject/$branchId/$subjectId"
    fun note(branchId: String, subjectId: String, noteIndex: Int) = "note/$branchId/$subjectId/$noteIndex"
    fun webview(title: String, url: String) =
        "webview/${URLEncoder.encode(title, "UTF-8")}/${URLEncoder.encode(url, "UTF-8")}"
    fun test(branchId: String, subjectId: String) = "test/$branchId/$subjectId"
    fun history(testId: String) = "history/${URLEncoder.encode(testId, "UTF-8")}"
}

fun decode(value: String): String = URLDecoder.decode(value, "UTF-8")

@Composable
fun StudentHubApp(viewModel: AppViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                branches = viewModel.branches,
                onBranchClick = { branch -> navController.navigate(Routes.branch(branch.id)) }
            )
        }
        composable(Routes.BRANCH) { backStackEntry ->
            val branchId = backStackEntry.arguments?.getString("branchId") ?: return@composable
            val branch = viewModel.findBranch(branchId) ?: return@composable
            BranchScreen(
                branch = branch,
                onBack = { navController.popBackStack() },
                onSubjectClick = { subject -> navController.navigate(Routes.subject(branchId, subject.id)) }
            )
        }
        composable(Routes.SUBJECT) { backStackEntry ->
            val branchId = backStackEntry.arguments?.getString("branchId") ?: return@composable
            val subjectId = backStackEntry.arguments?.getString("subjectId") ?: return@composable
            val subject = viewModel.findSubject(branchId, subjectId) ?: return@composable
            SubjectScreen(
                subject = subject,
                onBack = { navController.popBackStack() },
                onOpenNote = { index -> navController.navigate(Routes.note(branchId, subjectId, index)) },
                onOpenReferenceLink = { title, url -> navController.navigate(Routes.webview(title, url)) },
                onStartTest = {
                    viewModel.startTest(subject.test!!, subject.name)
                    navController.navigate(Routes.test(branchId, subjectId))
                },
                onViewHistory = { testId -> navController.navigate(Routes.history(testId)) }
            )
        }
        composable(Routes.NOTE) { backStackEntry ->
            val branchId = backStackEntry.arguments?.getString("branchId") ?: return@composable
            val subjectId = backStackEntry.arguments?.getString("subjectId") ?: return@composable
            val noteIndex = backStackEntry.arguments?.getString("noteIndex")?.toIntOrNull() ?: 0
            val subject = viewModel.findSubject(branchId, subjectId) ?: return@composable
            val note = subject.notes.getOrNull(noteIndex) ?: return@composable
            NoteDetailScreen(note = note, onBack = { navController.popBackStack() })
        }
        composable(Routes.WEBVIEW) { backStackEntry ->
            val title = decode(backStackEntry.arguments?.getString("title") ?: "")
            val url = decode(backStackEntry.arguments?.getString("url") ?: "")
            WebViewScreen(title = title, url = url, onBack = { navController.popBackStack() })
        }
        composable(Routes.TEST) { backStackEntry ->
            val branchId = backStackEntry.arguments?.getString("branchId") ?: return@composable
            val subjectId = backStackEntry.arguments?.getString("subjectId") ?: return@composable
            val test = viewModel.activeTest ?: return@composable
            TestScreen(
                test = test,
                answers = viewModel.answers,
                onSelectAnswer = viewModel::selectAnswer,
                onSubmit = {
                    viewModel.submitTest()
                    navController.navigate(Routes.RESULT) {
                        popUpTo(Routes.subject(branchId, subjectId))
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.RESULT) {
            val result = viewModel.lastResult ?: return@composable
            ResultScreen(
                result = result,
                answers = viewModel.answers,
                onRetake = {
                    viewModel.retakeActiveTest()
                    navController.popBackStack()
                },
                onViewHistory = { navController.navigate(Routes.history(result.test.id)) },
                onDone = { navController.popBackStack(Routes.HOME, inclusive = false) }
            )
        }
        composable(Routes.HISTORY) { backStackEntry ->
            val testId = decode(backStackEntry.arguments?.getString("testId") ?: "")
            HistoryScreen(
                attempts = viewModel.attemptsFor(testId),
                onBack = { navController.popBackStack() }
            )
        }
    }
}
