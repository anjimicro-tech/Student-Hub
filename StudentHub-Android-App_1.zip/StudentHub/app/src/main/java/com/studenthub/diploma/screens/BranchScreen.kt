package com.studenthub.diploma.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.studenthub.diploma.data.Branch
import com.studenthub.diploma.data.Subject

@Composable
fun BranchScreen(branch: Branch, onBack: () -> Unit, onSubjectClick: (Subject) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(branch.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            branch.semesters.forEach { semester ->
                item {
                    Text(
                        text = "Semester ${semester.number}",
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                items(semester.subjects) { subject ->
                    SubjectCard(subject = subject, onClick = { onSubjectClick(subject) })
                }
            }
        }
    }
}

@Composable
private fun SubjectCard(subject: Subject, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        androidx.compose.foundation.layout.Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(subject.name, style = MaterialTheme.typography.titleMedium)
                if (subject.code.isNotBlank()) {
                    Text(subject.code, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null)
        }
    }
}
