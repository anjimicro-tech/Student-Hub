package com.studenthub.diploma.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.studenthub.diploma.data.TestResult
import com.studenthub.diploma.ui.theme.Correct
import com.studenthub.diploma.ui.theme.Incorrect

@Composable
fun ResultScreen(
    result: TestResult,
    answers: Map<String, Int>,
    onRetake: () -> Unit,
    onViewHistory: () -> Unit,
    onDone: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Result") }) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Card(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(result.subjectName, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${result.score} / ${result.total}",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(top = 8.dp),
                        textAlign = TextAlign.Center
                    )
                    val percent = if (result.total > 0) (result.score * 100 / result.total) else 0
                    Text("$percent% correct", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(result.test.questions) { index, question ->
                    val chosen = answers[question.id]
                    val isCorrect = chosen == question.correctIndex
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("${index + 1}. ${question.text}", style = MaterialTheme.typography.titleMedium)
                            val chosenText = chosen?.let { question.options.getOrNull(it) } ?: "Not answered"
                            Text(
                                "Your answer: $chosenText",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isCorrect) Correct else Incorrect,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                            if (!isCorrect) {
                                Text(
                                    "Correct answer: ${question.options.getOrNull(question.correctIndex) ?: ""}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Correct,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            if (question.explanation.isNotBlank()) {
                                Text(
                                    question.explanation,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Button(onClick = onRetake, modifier = Modifier.fillMaxWidth()) {
                    Text("Retake this test")
                }
                OutlinedButton(onClick = onViewHistory, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text("View all my attempts")
                }
                OutlinedButton(onClick = onDone, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text("Back to home")
                }
            }
        }
    }
}
