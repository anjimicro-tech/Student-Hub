package com.studenthub.diploma.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue

data class TestResult(
    val test: MockTest,
    val subjectName: String,
    val score: Int,
    val total: Int
)

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ContentRepository(application)
    private val attemptsStore = AttemptsStore(application)

    val branches: List<Branch> = repository.loadBranches()

    // Transient state for the test currently being taken.
    var activeTest: MockTest? = null
        private set
    var activeSubjectName: String = ""
        private set
    val answers = mutableStateMapOf<String, Int>()

    var lastResult by mutableStateOf<TestResult?>(null)
        private set

    fun findBranch(branchId: String): Branch? = branches.find { it.id == branchId }

    fun findSubject(branchId: String, subjectId: String): Subject? =
        findBranch(branchId)?.semesters?.flatMap { it.subjects }?.find { it.id == subjectId }

    fun startTest(test: MockTest, subjectName: String) {
        activeTest = test
        activeSubjectName = subjectName
        answers.clear()
    }

    fun selectAnswer(questionId: String, optionIndex: Int) {
        answers[questionId] = optionIndex
    }

    fun submitTest(): TestResult {
        val test = activeTest ?: throw IllegalStateException("No active test")
        val score = test.questions.count { q -> answers[q.id] == q.correctIndex }
        val result = TestResult(test, activeSubjectName, score, test.questions.size)
        lastResult = result
        attemptsStore.addAttempt(
            TestAttempt(
                testId = test.id,
                subjectName = activeSubjectName,
                score = score,
                total = test.questions.size,
                timestampMillis = System.currentTimeMillis()
            )
        )
        return result
    }

    fun retakeActiveTest() {
        answers.clear()
    }

    fun attemptsFor(testId: String): List<TestAttempt> = attemptsStore.getAttemptsForTest(testId)
}
