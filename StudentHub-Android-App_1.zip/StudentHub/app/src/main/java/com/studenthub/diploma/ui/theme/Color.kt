package com.studenthub.diploma.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF1B5E20)
val GreenPrimaryLight = Color(0xFF4C8C4A)
val AmberAccent = Color(0xFFFFA000)
val Background = Color(0xFFF7F8F5)
val Surface = Color(0xFFFFFFFF)
val OnPrimary = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1A1C19)
val TextSecondary = Color(0xFF4A4F4A)
val Correct = Color(0xFF2E7D32)
val Incorrect = Color(0xFFC62828)
